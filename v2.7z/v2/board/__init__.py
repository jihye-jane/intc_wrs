# board/__init__.py

from .actuators import ActuatorControl

print("Board package loaded.")
