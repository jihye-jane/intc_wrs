# control/__init__.py

from .logic_controller import LogicController

print("Control package loaded.")
