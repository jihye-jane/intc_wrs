# logging/__init__.py

from .DataLogger import DataLogger

print("Logging package loaded.")
